import React, { useState } from 'react';
import Items from './components/Items';
import './App.css';
import Order from './components/Order';

function App() {
  const [menu, setMenu] = useState([]);
  const [namesArr,setNamesArr]=useState([]);
  const removeItem = id =>{
    const index = menu.findIndex(m=>m.id===id);
    const menuCopy = [...menu];
    menuCopy.splice(index,1);
    setMenu(menuCopy);
  }
  let total=0;
  let arrCost = menu.map(item=>{
    return item.cost
  });
  let arrCount = menu.map(item=>{
    return item.counter
  });
  for (let i=0;i<menu.length;i++){
    total+=arrCost[i]*arrCount[i];
  };


  let someText = ''

  if (menu.length===0){
   someText=`Order is empty! Please add some items`
  }
  else{
    someText='';
  }
  return (
    <div className="App">
      <div className="order">
      <h2>Order details:</h2>
      <div className="order_list">
        {someText}
        <Order  
        remove = {removeItem}        
        menu = {menu}
        />
        </div>
        <h2>Total price: {total} KZT</h2>
      </div>
      <div className="item_list">
      <h2>Add items:</h2>
      <div className='menu_grid'> 
        <Items 
        menu = {menu}
        setMenu = {setMenu}
        names={namesArr}
        setName = {setNamesArr}
        total={total}
        />
      </div>
      </div>
    </div>
  );
}

export default App;
