import React from 'react';

const Order = props =>{
    const styleMar={
        margin:'10px',
        cursor:'pointer'
    }
    const marg = {
        margin:'10px',
    }
    return props.menu.map((item)=>{
        return (
            <div className="order_text">
               
                <p style={marg} >{item.name} {item.cost} KZT</p>
                <p style={marg} >{item.counter}</p>
                <h2  style={styleMar} onClick={(id)=> props.remove(item.id)}>{item.delete}</h2>
            </div>
        )
    })
}

export default Order;