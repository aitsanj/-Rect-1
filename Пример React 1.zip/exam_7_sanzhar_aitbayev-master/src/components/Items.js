import React from 'react';

const Items = props =>{
    let menu = props.menu
    const setMenu = props.setMenu;
    const menuList = [{name:'Humburger', cost:80, id:'q',delete:'X',counter:1},{name:'Chesseburger', cost:90, id:'w',delete:'X',counter:1}, {name:'Fries', cost:45, id:'e',delete:'X',counter:1},{name:'Coffee', cost:70, id:'r',delete:'X',counter:1}, {name:'Tea', cost:50, id:'t',delete:'X',counter:1},{name:'Cola', cost:40, id:'y',delete:'X',counter:1}];
    const names=props.names;
    const setNames = props.setName;

    const addItem =id=>{
        const index = menuList.findIndex(m=>m.id ===id);
        
        const item ={...menuList[index]};
        const namesCopy=[...names];
        if (!namesCopy.includes(item.name)){
            namesCopy.push(item.name);
            setNames(namesCopy);
            const menuCopy = [...menu];
            menuCopy.push(item);
            setMenu(menuCopy);
        }
        else {
           const menuCopy = [...menu];
           for (let i=0;i<menuCopy.length;i++){
               if (menuCopy[i].name===item.name){
                   menuCopy[i].counter++;
                setMenu(menuCopy);
                }
           }

        } 
              
    }
    
    return menuList.map(item=>{        
        return (
            <div>
                <div onClick={(id)=> addItem(item.id)}className="list_items">
                    <p><strong>{item.name}</strong></p> 
                    <p>Price: {item.cost} KZT</p>
                </div>
            </div>
        )  
    })
}
export default Items;